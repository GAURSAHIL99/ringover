
import "./journey.css"
export const Journey = () => {
    return <div className="container journey-container">
        <div className="wrapper journey-wrapper">
        <header>
          <h2 className="headings Journey-title">
            The Journey
          </h2>
        </header>

        <div className="about-company">
            <ul>
                <li className="lists "><h3 className="heading about-title">The Roots</h3>
                <p className="text about-description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p></li>

                <li className="lists "><h3 className="heading about-title">Chapter I</h3>
                <p className="text about-description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p></li>

                <li className="lists "><h3 className="heading about-title">Chapter II</h3>
                <p className="text about-description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p></li>

                <li className="lists "><h3 className="heading about-title">KICKSUP</h3>
                <p className="text about-description">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p></li>
            </ul>
        </div>

        </div>
    </div>
}
export const Products = () => {
    return <h1>Products</h1>
}